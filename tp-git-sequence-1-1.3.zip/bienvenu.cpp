// Affiche un message de bienvenue
#include "fonction-bienvenue.h"
int main()
{
afficherBienvenue farouk();
return 0;
}
